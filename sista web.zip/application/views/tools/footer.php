       <!--Contact_section start -->
       <div class="contact_main">
           <div class="container">
               <div class="row">
                   <div class="col-sm-12">
                       <h1 class="touch_text">Kontak Kami</h1>
                   </div>
               </div>
           </div>
           <div class="contact_section_2">
               <div class="container">
                   <div class="row">
                       <div class="col-sm-4">
                           <div class="map_icon">
                               <img src="<?php echo base_url(); ?>assets/image/nf_again.jpg" style="max-width: 50%;padding-left: 30px; ">
                               <p class="">
                                   Jl. Raya Lenteng Agung No.20, RT.4/RW.1, Srengseng Sawah,
                                   Kec. Jagakarsa, Kota Jakarta Selatan, DKI Jakarta 12640
                               </p>
                           </div>
                       </div>
                       <div class="col-sm-4">
                           <div class="map_icon">
                               <img src="<?php echo base_url(); ?>assets/image/tilpun.png" style="max-width: 50%;padding-left: 30px;">
                               <p>+62 857 1624 3174</p>
                           </div>
                       </div>
                       <div class="col-sm-4">
                           <div class="map_icon">
                               <img src="<?php echo base_url(); ?>assets/image/stt_again.jpg" style="max-width: 50%; padding-left: 30px;">
                               <p>info@nurulfikri.ac.id</p>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
           <!--Contact_section end -->
           <div class="copyright">
               <div class="container">
                   <div class="row">
                       <div class="col-sm-12">
                           <p class="copyright_text">© 2020 SISTA. All rights reserved | Design by Kelompok 2
                               <a href="https://html.design">
                                   Mahasiswa STT NF</a>
                           </p>
                       </div>
                   </div>
               </div>
           </div>
       </div>
       <!-- Javascript files-->
       <script src="<?php echo base_url(); ?>assets/verification.js"></script>
       <script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
       <script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
       <script src="<?php echo base_url(); ?>assets/js/bootstrap.bundle.min.js"></script>
       </body>

       </html>