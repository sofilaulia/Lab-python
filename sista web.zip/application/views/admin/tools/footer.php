<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2021 <div class="bullet"></div> Design By <a href="">SISTA</a>
    </div>
    <div class="footer-right">

    </div>
</footer>
</div>
</div>

<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!-- General JS Scripts -->
<script src="<?php echo base_url(); ?>assets/admin/modules/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/modules/popper.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/modules/tooltip.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/modules/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/modules/nicescroll/jquery.nicescroll.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/modules/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/stisla.js"></script>

<!-- JS Libraies -->
<script src="<?php echo base_url(); ?>assets/admin/modules/jquery.sparkline.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/modules/chart.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/modules/owlcarousel2/dist/owl.carousel.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/modules/summernote/summernote-bs4.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/modules/chocolat/dist/js/jquery.chocolat.min.js"></script>

<!-- Page Specific JS File -->

<script src="<?php echo base_url(); ?>assets/admin/js/page/index.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/modules/sticky-kit.js"></script>
<!-- Template JS File -->
<script src="<?php echo base_url(); ?>assets/admin/js/scripts.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/custom.js"></script>
</body>

</html>