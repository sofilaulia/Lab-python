<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand sidebar-gone-show"><a href="<?php echo base_url(); ?>">SISTA</a></div>
        <ul class="sidebar-menu">
            <li><a class="nav-link" href="<?php echo base_url('User'); ?>"><i class="fas fa-pencil-ruler"></i> <span>Dashboard</span></a></li>
        </ul>

    </aside>
</div>