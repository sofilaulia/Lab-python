<?php
class M_BMI_Pasien extends CI_Model {
    public $id;
    public $tanggal;
    public $pasien;
    public $bmi;
}
