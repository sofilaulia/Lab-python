<?php
class M_Pasien extends CI_Model {
    public $id;
    public $kode;
    public $nama;
    public $email;
    public $gender;
    public $tmpt_lahir;
    public $tgl_lahir;
}
